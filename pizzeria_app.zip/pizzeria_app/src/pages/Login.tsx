import { useState, useContext } from 'react';
import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonInput,
  IonButton,
  IonText,
  IonCard,
  IonCardHeader,
  IonCardContent,
  IonLabel
} from '@ionic/react';
import { AuthContext } from '../Context/authContext';
import { loginUsuario } from '../Services/apiService';
import { useNavigate } from 'react-router-dom';
import './Login.css';

const Login = () => {
  const { setAuth } = useContext(AuthContext);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const navigate = useNavigate();

  const handleLogin = async () => {
    if (!email || !password) {
      setErrorMsg('Email y contraseña son requeridos');
      return;
    }

    try {
      const res = await loginUsuario({ email, password });
      setAuth(res.data.token, email);
      navigate('/pedido');
    } catch (err: any) {
      const mensaje = err.response?.data?.error || 'Error de red';
      setErrorMsg(mensaje);
    }
  };

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar color="primary">
          <IonTitle> Login</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent className="login-centro">
  <div className="login-wrapper">
    <IonCard className="login-card">
      <IonCardHeader>
        <IonLabel className="login-titulo">Accede a tu cuenta</IonLabel>
      </IonCardHeader>
        <IonCardContent>
          <IonInput
            label="Email"
            labelPlacement="floating"
            fill="outline"
            type="email"
            value={email}
            onIonChange={e => setEmail(e.detail.value!)}
            className="login-input"
          />
          <IonInput
            label="Contraseña"
            labelPlacement="floating"
            fill="outline"
            type="password"
            value={password}
            onIonChange={e => setPassword(e.detail.value!)}
            className="login-input"
          />
          <IonButton expand="block" onClick={handleLogin} className="login-button">
            Entrar
          </IonButton>
          {errorMsg && (
            <IonText className="login-error">
              <p>{errorMsg}</p>
            </IonText>
          )}
        </IonCardContent>
    </IonCard>
  </div>
</IonContent>

    </IonPage>
  );
};

export default Login;
