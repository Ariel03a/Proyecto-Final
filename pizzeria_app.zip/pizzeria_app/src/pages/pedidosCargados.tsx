import {
  IonContent,
  IonHeader,
  IonPage,
  IonTitle,
  IonToolbar,
  IonGrid,
  IonRow,
  IonCol,
  IonCard,
  IonCardHeader,
  IonCardTitle,
  IonCardContent,
  IonSpinner,
  IonBadge,
} from "@ionic/react";
import { useEffect, useState } from "react";
import axios from "axios";
import "./pedidosCargados.css";

interface Pedido {
  id_pedido: number;
  nombre_producto: string;
  categoria: string;
  cantidad: number;
  fecha: string;
  estado: string;
}

interface PedidoAgrupado {
  id_pedido: number;
  fecha: string;
  estado: string;
  productos: {
    nombre_producto: string;
    categoria: string;
    cantidad: number;
  }[];
}

const PedidosCargados: React.FC = () => {
  const [pedidos, setPedidos] = useState<Pedido[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const token = localStorage.getItem("token");

    axios
      .get("http://localhost:3000/api/pedidos", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      .then((res) => {
        console.log("Respuesta del backend:", res.data);
        const data = Array.isArray(res.data)
          ? res.data
          : res.data.pedidos ?? [];

        setPedidos(data);
        setLoading(false);
      })
      .catch((err) => {
        console.error("Error al obtener pedidos:", err);
        setError("No se pudieron cargar los pedidos.");
        setLoading(false);
      });
  }, []);

  const getEstadoColor = (estado: string): string => {
    switch (estado.toLowerCase()) {
      case "pendiente":
        return "warning";
      case "cancelado":
        return "danger";
      case "completado":
        return "success";
      default:
        return "medium";
    }
  };

  const agruparPedidos = (lista: Pedido[]): PedidoAgrupado[] => {
    const agrupados: { [id: number]: PedidoAgrupado } = {};

    lista.forEach((p) => {
      if (!agrupados[p.id_pedido]) {
        agrupados[p.id_pedido] = {
          id_pedido: p.id_pedido,
          fecha: p.fecha,
          estado: p.estado,
          productos: [],
        };
      }

      agrupados[p.id_pedido].productos.push({
        nombre_producto: p.nombre_producto,
        categoria: p.categoria,
        cantidad: p.cantidad,
      });
    });

    return Object.values(agrupados);
  };

  const pedidosAgrupados = agruparPedidos(pedidos);

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Pedidos cargados</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent fullscreen>
        {loading ? (
          <div style={{ textAlign: "center", marginTop: "2rem" }}>
            <IonSpinner name="dots" />
          </div>
        ) : error ? (
          <p style={{ color: "red", textAlign: "center" }}>{error}</p>
        ) : pedidosAgrupados.length === 0 ? (
          <p style={{ textAlign: "center" }}>No hay pedidos registrados.</p>
        ) : (
          <IonGrid>
            {pedidosAgrupados.map((pedido) => (
              <IonRow key={pedido.id_pedido}>
                <IonCol size="12">
                  <IonCard className="pedido-card">
                    <IonCardHeader>
                      <IonCardTitle>
                        Pedido #{pedido.id_pedido}{" "}
                        <IonBadge
                          color={getEstadoColor(pedido.estado)}
                          style={{ marginLeft: "8px" }}
                        >
                          {pedido.estado}
                        </IonBadge>
                      </IonCardTitle>
                    </IonCardHeader>
                    <IonCardContent>
                      {pedido.productos.map((prod, index) => (
                        <div key={index} style={{ marginBottom: "8px" }}>
                          <p><strong>Producto:</strong> {prod.nombre_producto}</p>
                          <p><strong>Categoría:</strong> {prod.categoria}</p>
                          <p><strong>Cantidad:</strong> {prod.cantidad}</p>
                          <hr />
                        </div>
                      ))}
                      <p><strong>Fecha:</strong> {new Date(pedido.fecha).toLocaleString()}</p>
                    </IonCardContent>
                  </IonCard>
                </IonCol>
              </IonRow>
            ))}
          </IonGrid>
        )}
      </IonContent>
    </IonPage>
  );
};

export default PedidosCargados;
