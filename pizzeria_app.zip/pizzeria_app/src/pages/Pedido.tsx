import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonInput,
  IonButton,
  IonLabel,
  IonItem,
  IonToast,
  IonCard,
  IonCardHeader,
  IonCardContent,
  IonIcon,
} from "@ionic/react";
import { useEffect, useState } from "react";
import { getProductos, crearPedido } from "../Services/apiService";
import LogoutButton from "../components/LogoutBottom";
import { sendOutline, listOutline } from "ionicons/icons";
import "./Pedido.css";

interface Producto {
  id: number;
  nombre: string;
  categoria: string;
}

const Pedido = () => {
  const [productos, setProductos] = useState<Producto[]>([]);
  const [categorias, setCategorias] = useState<string[]>([]);
  const [categoriaSeleccionada, setCategoriaSeleccionada] = useState<string>();
  const [productoId, setProductoId] = useState<number>();
  const [cantidad, setCantidad] = useState<number>(1);
  const [showToast, setShowToast] = useState(false);

  useEffect(() => {
    getProductos().then((data: Producto[]) => {
      const categoriasValidas = [
        "Especial",
        "Vegana",
        "Clasica",
        "Saludable",
        "Premium",
        "Entrada",
        "Bebida",
        "Postre",
      ];

      const productosFiltrados = data.filter((p) =>
        categoriasValidas.includes(p.categoria)
      );

      const productosUnicos = productosFiltrados.filter(
        (p, index, self) =>
          index ===
          self.findIndex(
            (q) => q.nombre === p.nombre && q.categoria === p.categoria
          )
      );

      setProductos(productosUnicos);
      setCategorias(categoriasValidas);
    });
  }, []);

  const productosFiltrados = productos.filter(
    (p) => p.categoria === categoriaSeleccionada
  );

  const handleSubmit = async () => {
    if (!productoId || !cantidad || !categoriaSeleccionada) {
      setShowToast(true);
      return;
    }

    await crearPedido([{ productoId, cantidad }]);
    setShowToast(true);
    setCantidad(1);
    setProductoId(undefined);
    setCategoriaSeleccionada(undefined);
  };

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar color="dark">
          <IonTitle>🍽️ Pedido</IonTitle>
          <LogoutButton />
        </IonToolbar>
      </IonHeader>

      <IonContent className="ion-padding pedido-centro">
        <div className="pedido-formulario">
          <IonCard>
            <IonCardHeader>
              <IonLabel className="titulo-formulario">Formulario de Pedido</IonLabel>
            </IonCardHeader>
            <IonCardContent>
              <div className="categoria-botones">
                {categorias.map((cat) => (
                  <IonButton
                    key={cat}
                    expand="block"
                    fill={categoriaSeleccionada === cat ? "solid" : "outline"}
                    onClick={() => setCategoriaSeleccionada(cat)}
                    className="boton-categoria"
                  >
                    {cat}
                  </IonButton>
                ))}
              </div>

              <IonItem>
                <IonLabel position="stacked">Plato</IonLabel>
                <select
                  className="select-plato"
                  value={productoId ?? ""}
                  onChange={(e) => setProductoId(parseInt(e.target.value))}
                >
                  <option value="" disabled>
                    Selecciona plato
                  </option>
                  {productosFiltrados.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.nombre}
                    </option>
                  ))}
                </select>
              </IonItem>

              <IonItem>
                <IonLabel position="floating">Cantidad</IonLabel>
                <IonInput
                  type="number"
                  value={cantidad}
                  onIonChange={(e) => setCantidad(parseInt(e.detail.value!, 10))}
                />
              </IonItem>

              <IonButton expand="block" onClick={handleSubmit} color="success" className="boton-pedido">
                <IonIcon icon={sendOutline} slot="start" />
                Enviar pedido
              </IonButton>

              <IonButton expand="block" routerLink="/pedidos" color="success" className="boton-pedido">
                <IonIcon slot="start" />
                Ver pedidos cargados
              </IonButton>
            </IonCardContent>
          </IonCard>
        </div>

        <IonToast
          isOpen={showToast}
          message="Pedido enviado correctamente o faltan campos"
          duration={2000}
          onDidDismiss={() => setShowToast(false)}
        />
      </IonContent>
    </IonPage>
  );
};

export default Pedido;
