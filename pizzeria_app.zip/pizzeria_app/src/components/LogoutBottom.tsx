import { useContext } from 'react';
import { IonButton } from '@ionic/react';
import { AuthContext } from '../Context/authContext';
import { useNavigate } from 'react-router-dom';

const LogoutButton = () => {
  const { setAuth } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleLogout = () => {
    setAuth('', '');
    localStorage.removeItem('token');
    navigate('/login');
  };

  return <IonButton onClick={handleLogout}>Cerrar sesión</IonButton>;
};

export default LogoutButton;
