import React, { createContext, useState } from 'react';

interface AuthContextType {
  token: string;
  email: string;
  setAuth: (token: string, email: string) => void;
}

export const AuthContext = createContext<AuthContextType>({
  token: '',
  email: '',
  setAuth: () => {}
});

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [token, setToken] = useState(() => localStorage.getItem('token') || '');
  const [email, setEmail] = useState(() => localStorage.getItem('email') || '');

  const setAuth = (newToken: string, newEmail: string) => {
    setToken(newToken);
    setEmail(newEmail);
    localStorage.setItem('token', newToken);
    localStorage.setItem('email', newEmail);
  };

  return (
    <AuthContext.Provider value={{ token, email, setAuth }}>
      {children}
    </AuthContext.Provider>
  );
};
