import axios from 'axios';

const BASE_URL = 'http://localhost:3000/api';

export const loginUsuario = async (data: { email: string; password: string }) => {
  return axios.post(`${BASE_URL}/auth/login`, data);
};

export const getProductos = async () => {
  const res = await axios.get(`${BASE_URL}/productos`);
  return res.data;
};

export const crearPedido = async (
  productos: { productoId: number; cantidad: number }[],
  estado: string = 'pendiente'
) => {
  const token = localStorage.getItem('token');

  if (!token) {
    throw new Error("Token no disponible. El usuario no está autenticado.");
  }

  const payload = {
    estado,
    productos: productos.map((p) => ({
      id_producto: p.productoId,
      cantidad: p.cantidad,
    })),
  };

  return axios.post(`${BASE_URL}/pedidos`, payload, {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });
};
