import { IonApp } from '@ionic/react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Login from './pages/Login';
import Pedido from './pages/Pedido';
import PedidosCargados from './pages/pedidosCargados';
import { AuthProvider } from './Context/authContext';

const App = () => (
  <IonApp>
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/pedido" element={<Pedido />} />
          <Route path="/pedidos" element={<PedidosCargados />} />
          <Route path="*" element={<Navigate to="/login" replace />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  </IonApp>
);

export default App;
