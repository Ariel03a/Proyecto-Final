const express = require('express');
require('dotenv').config();
const cors = require('cors'); 
const app = express();
const port = 3000;

// Configuración CORS frontend
app.use(cors({
  origin: 'http://localhost:8100', 
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  credentials: true
}));

app.use(express.json());

// Base de datos
const pool = require('./config/db');

// Rutas
const pedidosRoutes = require('./routes/pedidosRoutes');
const productosRoutes = require('./routes/productosRoutes');
const authRoutes = require('./routes/authRoutes');

app.use('/api/pedidos', pedidosRoutes);
app.use('/api/productos', productosRoutes);
app.use('/api/auth', authRoutes);

// Ruta de prueba movida para evitar conflicto
app.get('/api/pedidos/test', (req, res) => {
  res.json({ mensaje: 'Ruta de prueba de pedidos funcionando correctamente' });
});

// Ruta de prueba de conexión a la base de datos
app.get('/test-db', (req, res) => {
  pool.query('SELECT 1', (err, results) => {
    if (err) {
      console.error('Error en la consulta:', err);
      return res.status(500).json({ error: 'Error en la base de datos' });
    }
    res.json({ success: true, results });
  });
});

// Ruta raíz
app.get('/', (req, res) => {
  res.send('¡Bienvenido al backend de pedidos!');
});

// Inicio
app.listen(port, () => {
  console.log(`Servidor corriendo en http://localhost:${port}`);
});
