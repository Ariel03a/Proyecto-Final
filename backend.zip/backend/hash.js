const bcrypt = require('bcrypt');

bcrypt.hash('ariel', 10, (err, hash) => {
  console.log('Hash generado:', hash);
});
