const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');

// Variables de entorno
require('dotenv').config();
const JWT_SECRET = process.env.JWT_SECRET || 'clave_secreta';

// Registro 
router.post('/register', authController.register);

// Login
router.post('/login', authController.login);

module.exports = router;
