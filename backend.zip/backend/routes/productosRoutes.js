const express = require('express');
const router = express.Router();
const productosController = require('../controllers/productosController');
const VerifyToken = require ('../middleware/authMiddleware')

router.get('/', productosController.getAllProductos);
router.post('/', VerifyToken, productosController.createProducto);
router.put('/:id', VerifyToken, productosController.updateProducto);
router.delete('/:id', VerifyToken, productosController.deleteProducto);

module.exports = router;
