const express = require('express');
const router = express.Router();
const pedidosController = require('../controllers/pedidosController');
const verifyToken = require('../middleware/authMiddleware');
const pool = require('../config/db'); // ✅ Importación sin .promise()

// ✅ Ruta de prueba
router.get('/test', (req, res) => {
  res.json({ mensaje: 'Ruta de prueba de pedidos funcionando correctamente' });
});

// Crear pedido (necesita token)
router.post('/', verifyToken, pedidosController.createPedido);

// Obtener pedidos por usuario (necesita token)
router.get('/usuario', verifyToken, pedidosController.getPedidosByUsuario);

// Cancelar pedido por ID (necesita token)
router.delete('/:id', verifyToken, pedidosController.cancelPedido);

// ✅ Obtener todos los pedidos (sin Promesas, usando detalle_pedido)
router.get('/', verifyToken, (req, res) => {
  const query = `
    SELECT 
      p.id AS id_pedido,
      p.fecha,
      p.estado,
      pr.nombre AS nombre_producto,
      pr.categoria,
      dp.cantidad
    FROM pedidos p
    JOIN detalle_pedido dp ON p.id = dp.id_pedido
    JOIN productos pr ON dp.id_producto = pr.id
    ORDER BY p.fecha DESC
  `;

  pool.query(query, (err, results) => {
    if (err) {
      console.error('Error al obtener pedidos:', err);
      return res.status(500).json({ error: 'Error al obtener pedidos' });
    }

    res.json({ pedidos: results });
  });
});

router.put('/:id', verifyToken, pedidosController.updatePedido);

module.exports = router;
