const db = require('../config/db');

// Obtención
exports.getAllProductos = (req, res) => {
  db.query('SELECT * FROM productos', (err, results) => {
    if (err) return res.status(500).json({ error: 'Error al obtener productos' });
    res.json(results);
  });
};

// Creación
exports.createProducto = (req, res) => {
  const { nombre, precio } = req.body;
  if (!nombre || !precio) return res.status(400).json({ error: 'Nombre y precio son requeridos' });

  db.query('INSERT INTO productos (nombre, precio) VALUES (?, ?)', [nombre, precio], (err, result) => {
    if (err) return res.status(500).json({ error: 'Error al crear producto' });
    res.status(201).json({ id: result.insertId, nombre, precio });
  });
};

// Actualización
exports.updateProducto = (req, res) => {
  const { nombre, precio, descripcion } = req.body;
  const { id } = req.params;

  if (!id || !nombre || !precio) {
    return res.status(400).json({ error: 'ID, nombre y precio son requeridos' });
  }

  const query = 'UPDATE productos SET nombre = ?, precio = ?, descripcion = ? WHERE id = ?';
  db.query(query, [nombre, precio, descripcion || null, id], (err, result) => {
    if (err) return res.status(500).json({ error: 'Error al actualizar producto' });

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Producto no encontrado' });
    }

    res.json({ mensaje: 'Producto actualizado correctamente' });
  });
};



// Eliminación
exports.deleteProducto = (req, res) => {
  const { id } = req.params;

  db.query('DELETE FROM productos WHERE id = ?', [id], (err, result) => {
    if (err) return res.status(500).json({ error: 'Error al eliminar producto' });
    res.json({ mensaje: 'Producto eliminado correctamente' });
  });
};
