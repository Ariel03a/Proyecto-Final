const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const db = require('../config/db');

const secret = process.env.JWT_SECRET || 'clave_secreta';

exports.register = (req, res) => {
  const { email, password } = req.body;

  // Validación de entrada
  if (!email || !password) {
    console.error('Faltan campos en el registro');
    return res.status(400).json({ error: 'Se requiere email y contraseña' });
  }

  // Hasheo 
  const hashedPassword = bcrypt.hashSync(password, 8);

  // Nuevo usuario
  const query = 'INSERT INTO usuarios (email, password) VALUES (?, ?)';
  db.query(query, [email, hashedPassword], (err, result) => {
    if (err) {
      console.error('Error al registrar usuario en la base de datos:', err);
      return res.status(500).json({ error: 'Error al registrar usuario' });
    }

    res.status(201).json({ mensaje: 'Usuario registrado correctamente' });
  });
};

exports.login = (req, res) => {
  const { email, password } = req.body;

  // Validación de entrada
  if (!email || !password) {
    console.error('Faltan campos en el login');
    return res.status(400).json({ error: 'Se requiere email y contraseña' });
  }

  const query = 'SELECT * FROM usuarios WHERE email = ?';
  db.query(query, [email], (err, results) => {
    if (err) {
      console.error('Error al buscar usuario en la base de datos:', err);
      return res.status(500).json({ error: 'Error en el servidor' });
    }

    if (results.length === 0) {
      return res.status(401).json({ error: 'Credenciales inválidas' });
    }

    const user = results[0];
    const passwordIsValid = bcrypt.compareSync(password, user.password);

    if (!passwordIsValid) {
      return res.status(401).json({ error: 'Contraseña incorrecta' });
    }

    const token = jwt.sign({ id: user.id }, secret, { expiresIn: '2h' });
    res.json({ token });
  });
};
