const jwt = require('jsonwebtoken');
const pool = require('../config/db');

exports.createPedido = (req, res) => {
  const { estado, productos } = req.body;
  const userId = req.user.id;

  // Validación
  if (!estado || !Array.isArray(productos) || productos.length === 0) {
    return res.status(400).json({ error: 'Estado y productos válidos son requeridos' });
  }

  for (const producto of productos) {
    if (!producto.id_producto || !producto.cantidad || isNaN(producto.cantidad)) {
      return res.status(400).json({ error: 'Cada producto debe tener id_producto y cantidad válida' });
    }
  }

  pool.getConnection((err, connection) => {
    if (err) {
      console.error('Error al obtener conexión:', err);
      return res.status(500).json({ error: 'Error en la base de datos' });
    }

    connection.beginTransaction((err) => {
      if (err) {
        connection.release();
        console.error('Error al iniciar transacción:', err);
        return res.status(500).json({ error: 'Error al iniciar transacción' });
      }

      connection.query(
        'INSERT INTO pedidos (estado, id_usuario) VALUES (?, ?)',
        [estado, userId],
        (err, pedidoResult) => {
          if (err) {
            return connection.rollback(() => {
              connection.release();
              console.error('Error al insertar pedido:', err);
              res.status(500).json({ error: 'Error al crear pedido' });
            });
          }

          const pedidoId = pedidoResult.insertId;

          const inserts = productos.map((producto) => {
            return new Promise((resolve, reject) => {
              connection.query(
                'INSERT INTO detalle_pedido (id_pedido, id_producto, cantidad) VALUES (?, ?, ?)',
                [pedidoId, producto.id_producto, producto.cantidad],
                (err) => {
                  if (err) reject(err);
                  else resolve();
                }
              );
            });
          });

          Promise.all(inserts)
            .then(() => {
              connection.commit((err) => {
                connection.release();
                if (err) {
                  console.error('❌ Error al confirmar transacción:', err);
                  return res.status(500).json({ error: 'Error al confirmar pedido' });
                }
                res.status(201).json({ mensaje: 'Pedido creado correctamente', id_pedido: pedidoId });
              });
            })
            .catch((err) => {
              connection.rollback(() => {
                connection.release();
                console.error('❌ Error al insertar productos:', err);
                res.status(500).json({ error: 'Error al insertar productos del pedido' });
              });
            });
        }
      );
    });
  });
};

exports.getPedidosByUsuario = (req, res) => {
  const userId = req.user.id;

  const query = `
    SELECT 
      p.id AS id_pedido,
      p.estado,
      p.fecha,
      pr.nombre AS nombre_producto,
      pr.categoria,
      dp.cantidad
    FROM pedidos p
    JOIN detalle_pedido dp ON p.id = dp.id_pedido
    JOIN productos pr ON dp.id_producto = pr.id
    WHERE p.id_usuario = ?
    ORDER BY p.fecha DESC`;

  pool.query(query, [userId], (err, results) => {
    if (err) {
      console.error('Error al obtener pedidos:', err);
      return res.status(500).json({ error: 'Error al obtener pedidos' });
    }
    res.status(200).json({ pedidos: results });
  });
};

exports.cancelPedido = (req, res) => {
  const userId = req.user.id;
  const id_pedido = req.params.id;

  if (!id_pedido || isNaN(id_pedido)) {
    return res.status(400).json({ error: 'ID de pedido inválido' });
  }

  pool.query(
    'DELETE FROM detalle_pedido WHERE id_pedido = ?',
    [id_pedido],
    (err) => {
      if (err) {
        console.error('Error al eliminar detalle del pedido:', err);
        return res.status(500).json({ error: 'Error al eliminar productos del pedido' });
      }

      pool.query(
        'DELETE FROM pedidos WHERE id = ? AND id_usuario = ?',
        [id_pedido, userId],
        (err, result) => {
          if (err) {
            console.error('Error al cancelar pedido:', err);
            return res.status(500).json({ error: 'Error al cancelar pedido' });
          }

          if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Pedido no encontrado o no autorizado' });
          }

          res.status(200).json({ mensaje: 'Pedido cancelado correctamente' });
        }
      );
    }
  );
};

exports.updatePedido = (req, res) => {
  const userId = req.user.id;
  const id_pedido = req.params.id;
  const { estado } = req.body;

  // Validación
  if (!estado) {
    return res.status(400).json({ error: 'El campo "estado" es requerido' });
  }

  pool.query(
    'UPDATE pedidos SET estado = ? WHERE id = ? AND id_usuario = ?',
    [estado, id_pedido, userId],
    (err, result) => {
      if (err) {
        console.error('Error al actualizar pedido:', err);
        return res.status(500).json({ error: 'Error al actualizar el pedido' });
      }

      if (result.affectedRows === 0) {
        return res.status(404).json({ error: 'Pedido no encontrado o no autorizado' });
      }

      res.status(200).json({ mensaje: 'Pedido actualizado correctamente', id_pedido });
    }
  );
};
